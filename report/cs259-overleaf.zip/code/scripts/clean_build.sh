#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
make clean
scripts/build.sh
